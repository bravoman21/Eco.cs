# WindowsGSM.Eco
WindowsGSM plugin for [Eco](https://store.steampowered.com/app/382310/Eco/) Dedicated Server

## Requirements
[WindowsGSM](https://github.com/WindowsGSM/WindowsGSM) = 1.21.0

## Installation
Download the latest release of the Eco Dedicated Server from [here](https://github.com/bravoman21/WindowsGSM.Eco/blob/master/WindowsGSM.Eco.zip).

Once you have downloaded the .zip folder, you may either extract and move the Eco.cs folder into your WindowsGSM plugins folder or import the `<WindowsGSM.Eco.zip>` file directly with WindowsGSM.

Once added manually to the plugins folder or imported, click on the [RELOAD PLUGINS] button in WindowsGSM or restart WindowsGSM.
